public class Item {
    CharacterEffect itemEffect;

    public Item(CharacterEffect itemEffect){
        this.itemEffect = itemEffect;
    }

    public CharacterEffect getItemEffect() {
        return itemEffect;
    }
}
