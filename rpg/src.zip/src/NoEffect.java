public class NoEffect implements CharacterEffect {
    @Override
    public void call(Character c) {
        return;
    }
}
