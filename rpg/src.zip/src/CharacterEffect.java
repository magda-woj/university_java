public interface CharacterEffect {
    
    public void call(Character c);
}
